<?php
//FOR FORM VALIDATION  CALLBACKS TO WORK THIS FILE IS IMP
class MY_Form_validation extends CI_Form_validation 
{
    public $CI;
}

?>