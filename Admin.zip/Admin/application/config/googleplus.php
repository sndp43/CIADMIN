<?php

defined('BASEPATH') OR exit('No direct script access allowed');

/*$config['googleplus']['application_name'] = 'Dubai Fiance';
$config['googleplus']['client_id']        = '653373918992-h1778992q9vckatc4jshl9hhuageaald.apps.googleusercontent.com';
$config['googleplus']['client_secret']    = 'R8rOb_efljUvkj_ciyXW4OSt';
$config['googleplus']['redirect_uri']     = 'http://139.162.27.85/dubaifinance/Home/Login/gplogin';
$config['googleplus']['api_key']          = 'AIzaSyC-LFMlrgl_Q-gUn8Gm6jZnS-3MeEyhXE4';
$config['googleplus']['scopes']           = array();*/
$config['googleplus']['application_name'] = 'Simple_Login';
$config['googleplus']['client_id']        = '473789168650-08plsdskljkee2aok1pp74pg21mtpo8d.apps.googleusercontent.com';
$config['googleplus']['client_secret']    = '3DgWCpnlI8ltNr6pvopg0Dfr';
$config['googleplus']['redirect_uri']     = 'http://demo.anr.in/labs/Simple_Login/Register/gplogin';
// $config['googleplus']['api_key']          = 'AIzaSyCCPbYcQaqGzz5v_R24UqVCpRwAVE2oh38';
$config['googleplus']['api_key']          = 'AIzaSyDjkTPMznlOcQZXy5I3s807I19e8vC_Jk8';
$config['googleplus']['scopes']           = array();

