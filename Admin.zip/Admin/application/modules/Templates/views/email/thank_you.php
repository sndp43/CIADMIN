<table width="600" border="0" cellpadding="15" cellspacing="0" style="width:600px; margin:0px auto; height:auto; border:1px solid #111" > 
    <tbody>

        <tr>
           <td style="text-align:center; background:#23476f;" colspan="2"><img style="width:150px;" src="<?=base_url()?>assets/homefiles/images/logo.png" alt=""/></td>
        </tr> 


        <tr>
            <td style="font-family:Arial, sans-serif; font-size:14px;" colspan="2">
                <p style="text-align:justify; color:#000; font-size:12px; margin-top:19px; margin-bottom:19px;">
                Dear <?= $name?>,<br><br>
                   &nbsp;&nbsp;&nbsp; <?= $message ?><br><br><br>
                Regards,<br>
                Innovac Consulting.    
                </p>
            </td>
        </tr>

        <tr>


            <td  style="background:#23476f; width:100%;">
                <p style="text-align:left; color:#2b86e9; font-size:12px; float:right; font-family:Arial, sans-serif;" >&copy; <?php echo date("Y");?> Innovacconsulting.com All Rights Reserved.</p>

            </td>
        </tr>

    </tbody>
</table>


