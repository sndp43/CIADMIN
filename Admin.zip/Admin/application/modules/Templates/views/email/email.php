<!doctype html>
 <table width="600" border="0" cellpadding="15" cellspacing="0" style="width:600px; margin:0px auto; height:auto; border:1px solid #a1a1a1" >
  <tbody>

    <tr>
      <td style="text-align:center; background:#23476f;" colspan="2"><img style="width:150px;" src="<?=base_url()?>assets/homefiles/images/logo.png" alt=""/></td>
    </tr>
    
    <tr>
      <td style="font-family:Arial, sans-serif; font-size:12px !important;" colspan="2">
      <p style="text-align:justify; color:#000; font-size:12px !important; margin-bottom:20px; margin-top:20px;">
      <?= $body ?>
</p></td>
    </tr>
    
    <tr>
       
      <td  style="background:#111; width:100%;">
      <p style="text-align:left; color:#ccc; font-size:12px; float:right; font-family:Arial, sans-serif; line-height:0px;" >&copy;  <?= date('Y'); ?> <?= get_appname() ?> All Rights Reserved.</p>
      </td>
    </tr>
    
  </tbody>
</table>


