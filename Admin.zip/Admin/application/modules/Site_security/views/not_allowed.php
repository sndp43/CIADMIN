 <!DOCTYPE html>
<html>
<head>
<title>unauthorised</title>
</head>

<body>
 <center><img src="<?= base_url() ?>assets/adminfiles/security/not_allowed.jpeg"></center>
 <center>You are not allowed to be here</center>
</body>

</html> 