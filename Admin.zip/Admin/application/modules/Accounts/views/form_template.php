   <div class="page">
    <div class="page-header">
   
   <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 gap right_side_dash colm" >
<!-- <div class="row">
<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 gap period">
<p>Period for Selection Should be maximum 6 Months Only.</p>
</div>
</div> -->
<div class="row">
<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 gap supplier">
<h2><span>Title</span></h2>
<ul>
<li><a href="#">Home</a></li>
<li><a href="#">Title</a></li>
</ul>
<form>  
<div class="row">
<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 gap detail mCustomScrollbar _mCS_4s">


<div class="row">
<div class="form1">
  <p>First name:</p>
  <input type="text" name="firstname">
  <br>
  <p>Last name:</p>
  <input type="text" name="firstname">
  <br>
  <p>Contactno:</p>
  <input type="text" name="firstname">
  <br>
  <p>Email-id:</p>
  <input type="text" name="firstname">
  <br>
  <p>Address:</p>
  <input type="text" name="firstname">
  <br>
  <p>Date:</p>
  <div class="date-picker">
<div class="input">
<div class="result">Select Date: <span></span></div>
<button><i class="fa fa-calendar"></i></button>
</div>
<div class="calendar"></div>
</div>

<div class="spend1">
<input type="button" value="submit"/>
<input type="button" value="cancel"/>

</div>


</div>


</div>



</div>
</div> 

  
</form>      
</div>
</div>
</div>
   
    </div>

  </div>